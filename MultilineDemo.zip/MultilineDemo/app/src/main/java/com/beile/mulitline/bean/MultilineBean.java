package com.beile.mulitline.bean;

public class MultilineBean {
	private String mTitle;

	public String getTitle() {
		return mTitle;
	}

	public void setTitle(String title) {
		this.mTitle = title;
	}

}
